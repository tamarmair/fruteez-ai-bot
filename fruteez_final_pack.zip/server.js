
// קובץ שרת Node.js פשוט עם Express
// מקבל בקשה POST עם day, fruit, style
// יוצר פוסט + תמונה דרך OpenAI ומחזיר תוצאה ללקוח

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios');

const app = express();
const port = process.env.PORT || 3000;

const OPENAI_KEY = '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';

app.use(cors());
app.use(bodyParser.json());

app.post('/generate', async (req, res) => {
  const { day, fruit, style } = req.body;
  try {
    // 1. יצירת טקסט
    const textPrompt = `צור פוסט לפייסבוק עבור עסק בשם Fruteez שמוכר פירות קפואים. היום הוא ${day}, הפרי הוא ${fruit}, וסגנון הכתיבה הוא ${style}. הפוסט בעברית, באורך 3-4 שורות.`;

    const textRes = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-4',
      messages: [{ role: 'user', content: textPrompt }]
    }, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_KEY}`
      }
    });

    const postText = textRes.data.choices?.[0]?.message?.content;

    // 2. יצירת תמונה
    const imagePrompt = `${fruit} קפוא, אווירה של ${day}, מתאים לעסק ברשתות חברתיות`;
    const imgRes = await axios.post('https://api.openai.com/v1/images/generations', {
      model: 'dall-e-3',
      prompt: imagePrompt,
      n: 1,
      size: '1024x1024'
    }, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_KEY}`
      }
    });

    const imageUrl = imgRes.data.data?.[0]?.url;

    res.json({ text: postText, image: imageUrl });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'שגיאה בתקשורת עם OpenAI', details: err.message });
  }
});

app.listen(port, () => {
  console.log(`🚀 Server ready at http://localhost:${port}`);
});
