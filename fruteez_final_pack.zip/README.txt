
📦 Fruteez AI Bot - הוראות לפריסה

1. פתחי חשבון ב-Render: https://render.com (או Railway.app)
2. צרי שירות חדש מסוג Web Service
3. העלי את הקבצים מתוך ה-ZIP הזה
4. ודאי שמוגדר:
   - start command: node server.js
   - runtime: Node 18+
   - port: 3000 (Render בוחר אוטומטית)
5. האפליקציה תיפתח בכתובת שתתקבל לאחר הפריסה

קובץ index.html הוא החלק שגולשים רואים
קובץ server.js מבצע את הבקשות ל-AI
